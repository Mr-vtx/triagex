# Changelog

All notable changes are listed here. The format follows [Keep a Changelog](https://keepachangelog.com/).

## [Unreleased] - heading to 0.1.0

### Added
- `triagex` overview, `report` (text, JSON, Markdown), `check` and `about`.
- System checks: CPU load, memory and swap, disk space and inodes, failed systemd units.
- Log triage: journald and file sources, grouping with stable IDs, timelines, secret redaction.
- Docker diagnostics over the local socket (read-only): crash loops, OOM kills, health, restarts, exit codes explained.
- Redis diagnostics (`PING` and `INFO` only, no credentials): memory, evictions, persistence, replication, latency.
- Process view: top CPU and memory processes in the overview, `check`, `report` and JSON. CPU% comes from two `/proc` readings taken around the other checks, so it adds no run time. Names only: command lines are never collected because they often contain secrets. Process names are stripped of control characters before display.
- `process.zombies` and `process.stuck` findings; the CPU-load and low-memory findings now name the busiest or largest process as evidence (never as a cause).
- File integrity: `baseline` and `verify` with BLAKE3, tamper-evident baselines, setuid and sensitive-path detection.
- Terminal UI: ASCII logo, panels, gauges, two themes, responsive from 40 to 100 columns, ASCII fallback.
- `--anonymize` to mask IPs, hostname and user name in any output.
- Finding and log-group IDs shown in the terminal, matching JSON and Markdown.
- Static musl release pipeline (x86_64, aarch64), `install.sh` with checksum verification, weekly `cargo audit`.
- `scripts/smoke.sh` (real Docker and Redis) and `scripts/vps-run.sh` (real-server run kit).

### Fixed
- Log grouping: numbers glued to units (`2840112kB`, `250ms`) and short, letter-only or numeric request IDs no longer split groups (a 1M-line test went from 86,682 groups to 4).
- Docker: a container killed with exit 137 and a memory limit is now reported as a probable OOM kill even when Docker does not set `OOMKilled`.
- Disk finding suggests `lsof +L1` for deleted-but-open files (reported by a reader).
- Installer rejects version tags containing anything but letters, digits, `.`, `_`, `-`.

### Security
- No outbound network. Docker GET-only. Redis never sends credentials.
- Baselines are stored `0600`/`0700` and carry a digest that detects edits.
